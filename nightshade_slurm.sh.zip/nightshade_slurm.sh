#!/bin/bash
#SBATCH --job-name=poison_job              # Name of the job
#SBATCH --array=0-594                        # Array index, this should be set to the number of images minus one
#SBATCH --nodes=1                          # Number of nodes
#SBATCH --partition=a100-8-gm320-c96-m1152   # Partition name
#SBATCH --output=%x_%A_%a.out              # Name of the output file (%A for array job ID, %a for array index)
#SBATCH --error=%x_%A_%a.err               # Name of the error file
#SBATCH --gpus=1                           # Number of GPUs needed per task
#SBATCH --mem=10G                          # Memory needed per task
#SBATCH --time=00:45:00                    # Time requested per task
#SBATCH --mail-type=begin,end,fail         # Send mail for specified events
#SBATCH --mail-user=psuo2@emory.edu        # Replace with your email

# Correctly initialize Conda for bash scripting
source /etc/profile.d/conda.sh  # Ensure this path is correct on your system
conda activate hypersetup       # Activate conda environment

cd /users/psuo2/Original

# Correctly handling the files based on your previous input images seem to be pickled (.p) files
IMAGES=($(ls *.p))

if [ -z "$IMAGES" ]; then
  echo "No .p files found."
  exit 1
fi

IMAGE=${IMAGES[$SLURM_ARRAY_TASK_ID]}

# Define an array of prompts
PROMPTS=(
    "an_artwork_in_the_style_of_Abstract_Expressionism"
    "an_artwork_in_the_style_of_Action_Painting"
    "an_artwork_in_the_style_of_Art_Deco"
    "an_artwork_in_the_style_of_Art_Nouveau"
    "an_artwork_in_the_style_of_Baroque"
    "an_artwork_in_the_style_of_Bauhaus"
    "an_artwork_in_the_style_of_Byzantine"
    "an_artwork_in_the_style_of_Cubism"
    "an_artwork_in_the_style_of_Dada"
    "an_artwork_in_the_style_of_De_Stijl"
    "an_artwork_in_the_style_of_Divisionism"
    "an_artwork_in_the_style_of_Expressionism"
    "an_artwork_in_the_style_of_Fauvism"
    "an_artwork_in_the_style_of_Futurism"
    "an_artwork_in_the_style_of_Gothic"
    "an_artwork_in_the_style_of_Hard_edge_Painting"
    "an_artwork_in_the_style_of_Hyperrealism"
    "an_artwork_in_the_style_of_Industrial_Design"
    "an_artwork_in_the_style_of_Installation_Art"
    "an_artwork_in_the_style_of_International_Style"
    "an_artwork_in_the_style_of_Land_Art"
    "an_artwork_in_the_style_of_Luminism"
    "an_artwork_in_the_style_of_Magic_Realism"
    "an_artwork_in_the_style_of_Mannerism"
    "an_artwork_in_the_style_of_Minimalism"
    "an_artwork_in_the_style_of_Modernism"
    "an_artwork_in_the_style_of_Neoclassicism"
    "an_artwork_in_the_style_of_Op_Art"
    "an_artwork_in_the_style_of_Orphism"
    "an_artwork_in_the_style_of_Photorealism"
    "an_artwork_in_the_style_of_Pointillism"
    "an_artwork_in_the_style_of_Pop_Art"
    "an_artwork_in_the_style_of_Postmodernism"
    "an_artwork_in_the_style_of_Precisionism"
    "an_artwork_in_the_style_of_Pre_Raphaelite"
    "an_artwork_in_the_style_of_Realism"
    "an_artwork_in_the_style_of_Renaissance"
    "an_artwork_in_the_style_of_Rococo"
    "an_artwork_in_the_style_of_Romanticism"
    "an_artwork_in_the_style_of_Surrealism"
    "an_artwork_in_the_style_of_Symbolism"
    "an_artwork_in_the_style_of_Tachisme"
    "an_artwork_in_the_style_of_Tribal_Art"
    "an_artwork_in_the_style_of_Ukiyo_e"
    "an_artwork_in_the_style_of_Vorticism"
    "an_artwork_in_the_style_of_Brutalism"
    "an_artwork_in_the_style_of_Constructivism"
    "an_artwork_in_the_style_of_Cyberpunk"
    "an_artwork_in_the_style_of_Digital_Art"
    "an_artwork_in_the_style_of_Graffiti"
    "an_artwork_in_the_style_of_Lowbrow"
    "an_artwork_in_the_style_of_Outsider_Art"
    "an_artwork_in_the_style_of_Suprematism"
    "an_artwork_in_the_style_of_Abstract_Art"
    "an_artwork_in_the_style_of_Conceptual_Art"
    "an_artwork_in_the_style_of_Concrete_Art"
    "an_artwork_in_the_style_of_Figurative_Art"
    "an_artwork_in_the_style_of_Found_Object_Art"
    "an_artwork_in_the_style_of_Geometric_Abstraction"
    "an_artwork_in_the_style_of_Kinetic_Art"
    "an_artwork_in_the_style_of_Performance_Art"
    "an_artwork_in_the_style_of_Video_Art"
    "an_artwork_in_the_style_of_Street_Art"
    "an_artwork_in_the_style_of_Psychedelic_Art"
    "an_artwork_in_the_style_of_Visionary_Art"
    "an_artwork_in_the_style_of_Neo_Dada"
    "an_artwork_in_the_style_of_Fluxus"
    "an_artwork_in_the_style_of_Neo_Expressionism"
    "an_artwork_in_the_style_of_Social_Realism"
    "an_artwork_in_the_style_of_Symbolic_Art"
    "an_artwork_in_the_style_of_Fantasy_Art"
    "an_artwork_in_the_style_of_Steam_Punk"
    "an_artwork_in_the_style_of_Bio_Art"
    "an_artwork_in_the_style_of_Algorithmic_Art"
    "an_artwork_in_the_style_of_Feminist_Art"
    "an_artwork_in_the_style_of_Environmental_Art"
    "an_artwork_in_the_style_of_Post_Internet_Art"
)

# Select prompt based on the SLURM array task ID
PROMPT=${PROMPTS[$SLURM_ARRAY_TASK_ID % ${#PROMPTS[@]}]}

# Ensure this path to `poison.py` is correct
python3 /users/psuo2/NightShade/poison.py -i $IMAGE -od /users/psuo2/Poisoned -e 0.04 -t $PROMPT